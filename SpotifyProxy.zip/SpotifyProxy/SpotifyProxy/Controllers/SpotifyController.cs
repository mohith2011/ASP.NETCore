﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Polly;
using Serilog;
using SpotifyProxy.DTOS.Response;
using SpotifyProxy.Filters;
using SpotifyProxy.Helpers;
using SpotifyProxy.Models;
using SpotifyProxy.Services;
using StackExchange.Profiling;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SpotifyProxy.Controllers
{

    [Route("api/{v:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [ApiController]
    public class SpotifyController : ControllerBase
    {
        private ISpotifyProxyService _spotifyProxyService;
        private IMapper _mapper;
        private readonly ITokenService _tokenService;
       

        public SpotifyController(ISpotifyProxyService spotifyProxyService, IMapper mapper,ITokenService tokenService)
        {
            _spotifyProxyService = spotifyProxyService;
            _mapper = mapper;
            _tokenService = tokenService;
            
        }
        // GET: api/<SpotifyController>
        [HttpGet("getToken")]
        public async Task<IActionResult> Get()
        {
            using (MiniProfiler.Current.Step("Time taken to get token"))
            {
                var result = await _tokenService.GetToken();
                Log.Information("Token Generated Successfully");
                return Ok(result);
            }
            
        }

        // GET api/<SpotifyController>/5
        [HttpGet("{id}")]
        [ValidateModel]
        public async Task<IActionResult> Get([RegularExpression("^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$",ErrorMessage ="ID must be in AlphaNumeric" )]String id)
        {
            Request.Headers.TryGetValue("tranid", out var tranid);
            Log.Information("ArtistAlbums Api Triggered");
            var res = await _spotifyProxyService.GetArtistAlbums(id, tranid);
            var res2 = await _spotifyProxyService.GetArtist(id, tranid);
            if (res.StatusCode == 200 && res2.StatusCode == 200)
            {
                ArtistAlbums artistAlbums = (ArtistAlbums)res.ResponseBody;
                Artist artist = (Artist)res2.ResponseBody;
                return Ok(_mapper.Map<ArtistAlbums, ArtistAlbumsDto>(artistAlbums, _mapper.Map<ArtistAlbumsDto>(artist)));
            }
            else
            {
                throw new InvalidOperationException("Invalid id, please enter valid id");
            }
        }
    }
}
