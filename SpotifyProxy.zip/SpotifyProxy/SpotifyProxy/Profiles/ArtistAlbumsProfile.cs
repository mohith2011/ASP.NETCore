﻿using AutoMapper;
using SpotifyProxy.DTOS.Response;
using SpotifyProxy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SpotifyProxy.Profiles
{
    public class ArtistAlbumsProfile :Profile
    {
        public ArtistAlbumsProfile()
        {
            CreateMap<Artist, ArtistAlbumsDto>()
                .ForMember(dest=>dest.ArtistName,opts=>opts.MapFrom(source=>source.Name))
                .ForMember(dest=>dest.Followers,opts=>opts.MapFrom(source=>source.Followers.Total));
            CreateMap<ArtistAlbums, ArtistAlbumsDto>()
                .ForMember(dest => dest.Albums, opts => opts.MapFrom(source => source.Items));
            CreateMap<Item, Album>();
        }
    }
}
