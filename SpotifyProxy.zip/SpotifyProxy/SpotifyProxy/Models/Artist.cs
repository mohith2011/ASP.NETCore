﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Models
{
    public class Artist
    {
        public String Href { get; set; }
        public List<String> Genres { get; set; }
        public String Id { get; set; }
        public String Name { get; set; }
        public int Popularity { get; set; }
        public String Type { get; set; }
        public String Uri { get; set; }
        public List<Image> Images { get; set; }
        public Follower Followers { get; set; }
        public ExternalUrls External_urls { get; set; }
    }

    public class Image
    {
        public int Height { get; set; }
        public String Url { get; set; }
        public int Width { get; set; }
    }
    public class Follower
    {
        public String Href { get; set; }
        public int Total { get; set; }
    }
    public class ExternalUrls
    {
        public String Spotify { get; set; }
    }
}
