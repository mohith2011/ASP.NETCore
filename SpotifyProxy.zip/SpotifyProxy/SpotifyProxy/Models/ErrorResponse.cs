﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace SpotifyProxy.Models
{
    public class ErrorResponse
    {
        /// <summary>
        /// Error Code
        /// </summary>
        [DataMember(Name = "httpCode")]
        public int HttpCode { get; set; }

        /// <summary>
        /// Error Desription
        /// </summary>
        [DataMember(Name = "httpMessage")]
        public string HttpMessage { get; set; }

        /// <summary>
        /// ResponseMessage constructor
        /// </summary>
        /// <param name="statusCode"></param>
        /// <param name="errorMessage"></param>
       
        public ErrorResponse(int statusCode, string errorMessage)
        {
            HttpCode = statusCode;
            HttpMessage = errorMessage;
        }
    }
}
