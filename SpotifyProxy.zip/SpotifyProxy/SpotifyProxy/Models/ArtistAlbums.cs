﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Models
{
    public class ArtistAlbums
    {
        public List<Item> Items { get; set; }
    }

    public class Item
    {
        public String Href { get; set; }
        public String Name { get; set; }
        public String Release_date { get; set; }

    }
}
