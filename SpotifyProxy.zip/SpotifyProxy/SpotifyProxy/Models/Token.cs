﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Models
{
    public class Token
    {
        /// <summary>
        /// 
        /// </summary>
        public String Access_token { get; set; }
        public String Token_type { get; set; }
        public int Expires_in { get; set; }
        public String Scope { get; set; }
        public DateTime ExpiresAt { get; internal set; }
    }
}
