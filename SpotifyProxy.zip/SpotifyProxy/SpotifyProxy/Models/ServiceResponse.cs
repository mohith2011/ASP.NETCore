﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Models
{
    public class ServiceResponse
    {
        public int StatusCode { get; set; }
        public String ErrorMessage { get; set; }
        public Object ResponseBody { get; set; }
    }
}
