﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using SpotifyProxy.Helpers;
using SpotifyProxy.Models;
using StackExchange.Profiling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Middleware
{
    public class ErrorHandlerMiddleware
    {
        #region Declaration

        /// <summary>
        /// To process HTTP request
        /// </summary>
        private readonly RequestDelegate _next;

        /// <summary>
        /// Constructor for ErrorHandlerMiddleware
        /// </summary>
        /// <param name="nextReq"></param>
        public ErrorHandlerMiddleware(RequestDelegate nextReq)
        {
            _next = nextReq;
        }
        #endregion

        #region Invoke
        /// <summary>
        /// Invoke HTTP request
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns>returns response</returns>
        public async System.Threading.Tasks.Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext).ConfigureAwait(continueOnCapturedContext: false);
            }
            catch(InvalidOperationException io)
            {
                using (MiniProfiler.Current.Step(Constants.BadRequestError))
                {
                    Log.Error("ErrorHandlerMiddleware - " + io.Message);

                    // handles Exception as 400 status code
                    await HandleExceptionAsync(httpContext,
                        io.Message,
                        Constants.BadRequestHttpCode
                        ).ConfigureAwait(continueOnCapturedContext: false);
                }

            }
            catch (Exception ex)
            {
                using (MiniProfiler.Current.Step(Constants.InternalServerError))
                {
                    Log.Error("ErrorHandlerMiddleware - " + ex.Message);
                   
                    // handles Exception as 500 status code
                    await HandleExceptionAsync(httpContext,
                        ex.Message ,
                        ex.Message == Constants.InvalidRequestError ? Constants.BadRequestHttpCode : Constants.InternalServerErrorHttpCode
                        ).ConfigureAwait(continueOnCapturedContext: false);
                }
            }
        }
        #endregion

        #region HandleExceptionAsync

        private static System.Threading.Tasks.Task HandleExceptionAsync(HttpContext context, string errorMsg, int httpStatusCode)
        {
            // log error
            Log.Error("ErrorHandlerMiddleware - " + errorMsg);
            var errorResponse = new ErrorResponse(httpStatusCode, errorMsg);
            var jsonContent = JsonConvert.SerializeObject(errorResponse);
            context.Response.StatusCode = httpStatusCode;
            context.Response.ContentType = Constants.JsonContentType;
            return context.Response.WriteAsync(jsonContent);
        }

        #endregion
}
}
