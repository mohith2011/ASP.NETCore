﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.DTOS.Response
{
    public class ArtistAlbumsDto
    {
        public String ArtistName { get; set; }
        public int Popularity { get; set; }
        public int Followers { get; set; }
        public List<Album> Albums { get; set; }
    }

    public class Album
    {
        public String Name { get; set; }
        public String Release_date { get; set; }
        public String Href { get; set; }
    }
}
