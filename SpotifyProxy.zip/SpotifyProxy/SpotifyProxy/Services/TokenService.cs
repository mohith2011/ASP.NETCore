﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using SpotifyProxy.Helpers;
using SpotifyProxy.Middleware;
using SpotifyProxy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace SpotifyProxy.Services
{
    public class TokenService : ITokenService
    {
        private Token _token;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IOptions<UserSettings> _options;

        public TokenService(IHttpClientFactory clientFactory, IOptions<UserSettings> options)
        {
            _clientFactory = clientFactory;
            _options = options;
        }
       
        public async Task<Token> GetToken()
        {

            if (_token == null || DateTime.Compare(DateTime.UtcNow, _token.ExpiresAt) > 0)
            {
                ServiceResponse serviceResponse = await GetNewToken();
                if (serviceResponse.StatusCode == 200)
                {
                    _token = (Token)serviceResponse.ResponseBody;
                    return _token;
                }
                else
                {
                    throw new Exception("Access Token not generated");
                }              
            }

            return _token;

        }

        public async Task<ServiceResponse> GetNewToken()
        {
            Log.Information("Getting New Token");
            var client = _clientFactory.CreateClient("GetToken");
            var request = new HttpRequestMessage(HttpMethod.Post, _options.Value.TokenPath);

            List<KeyValuePair<String, String>> parameters = new List<KeyValuePair<string, string>>();
            parameters.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));

            request.Content = new FormUrlEncodedContent(parameters);
            request.Headers.Add("authorization", "Basic " + System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(_options.Value.ClientId + ":" + _options.Value.Secret)));

            if (AuditMiddleware.Logger != null)
                AuditLogger.RequestInfo(string.Empty, "GET", "/v1/token", string.Empty, JsonConvert.SerializeObject(request).ToString());
            var res = await client.SendAsync(request);         
            if (AuditMiddleware.Logger != null)
                AuditLogger.ResponseInfo(string.Empty, "GET", "/v1/token", string.Empty, JsonConvert.SerializeObject(res).ToString());

            var resBody = await res.Content.ReadAsStringAsync();

            ServiceResponse serviceResponse = new ServiceResponse
            {
                StatusCode = (int)res.StatusCode
            };
            if (serviceResponse.StatusCode == 200)
            {
                Token token = JsonConvert.DeserializeObject<Token>(resBody);
                token.ExpiresAt = DateTime.UtcNow.AddSeconds(token.Expires_in);
                serviceResponse.ResponseBody = token;
                return serviceResponse;
            }
            else
            {
                serviceResponse.ErrorMessage = "Unable to fetch Refresh Token";
                return serviceResponse;
            }
        }

    }
}
