﻿using SpotifyProxy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Services
{
    public interface ITokenService
    {
        Task<Token> GetToken();
    }
}
