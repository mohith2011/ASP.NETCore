﻿using SpotifyProxy.Models;
using System;
using System.Threading.Tasks;


namespace SpotifyProxy.Services
{
    public interface ISpotifyProxyService
    {
        Task<ServiceResponse> GetArtist(String id,String tranid);
        Task<ServiceResponse> GetArtistAlbums(String id,String tranid);
        

    }
}
