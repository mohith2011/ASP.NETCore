﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using SpotifyProxy.Helpers;
using SpotifyProxy.Middleware;
using SpotifyProxy.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace SpotifyProxy.Services
{
    public class SpotifyProxyService : ISpotifyProxyService
    {

        private readonly IHttpClientFactory _clientFactory;
        private readonly IOptions<UserSettings> _options;
        private readonly ITokenService _tokenService;

        public SpotifyProxyService(IHttpClientFactory clientFactory, IOptions<UserSettings> options, ITokenService tokenService)
        {
            _clientFactory = clientFactory;
            _options = options;
            _tokenService= tokenService;
        }


        public async Task<ServiceResponse> GetArtist(string id,String tranid)
        {
            var token= await _tokenService.GetToken();
            var client = _clientFactory.CreateClient("GetSpotifyClient");
            var request = new HttpRequestMessage(HttpMethod.Get, _options.Value.Apipath1+id);

            
            request.Headers.Add("authorization", "Bearer " + token.Access_token);
            if (AuditMiddleware.Logger != null)
                AuditLogger.RequestInfo(tranid, "GET", "/v1/artist/{id}", id, JsonConvert.SerializeObject(request).ToString());
            var res = await client.SendAsync(request);          
            if (AuditMiddleware.Logger != null)
                AuditLogger.ResponseInfo(tranid, "GET", "/v1/artist/{id}", id, JsonConvert.SerializeObject(res).ToString());
            var resBody = await res.Content.ReadAsStringAsync();

            ServiceResponse serviceResponse = new ServiceResponse
            {
                StatusCode = (int)res.StatusCode
            };
            if (serviceResponse.StatusCode == 200)
            {
                serviceResponse.ResponseBody = JsonConvert.DeserializeObject<Artist>(resBody);
                return serviceResponse;
            }
            else
            {
                serviceResponse.ErrorMessage ="Unable to fetch artist/ artist id does not exist";
                return serviceResponse;
            }
            
        }

        public async Task<ServiceResponse> GetArtistAlbums(string id,string tranid)
        {
            var token = await _tokenService.GetToken();
            var client = _clientFactory.CreateClient("GetSpotifyClient");
            var request = new HttpRequestMessage(HttpMethod.Get, _options.Value.Apipath1 + id+ _options.Value.Apipath2);


            request.Headers.Add("authorization", "Bearer " + token.Access_token);

            if (AuditMiddleware.Logger != null)
                AuditLogger.RequestInfo(tranid, "GET", "/v1/artist/Albums/{id}", id, JsonConvert.SerializeObject(request).ToString());
            var res = await client.SendAsync(request);
            if (AuditMiddleware.Logger != null)
                AuditLogger.ResponseInfo(tranid, "GET", "/v1/artist/Albums/{id}", id, JsonConvert.SerializeObject(res).ToString());
            var resBody = await res.Content.ReadAsStringAsync();

            ServiceResponse serviceResponse = new ServiceResponse
            {
                StatusCode = (int)res.StatusCode
            };
            if (serviceResponse.StatusCode == 200)
            {
                serviceResponse.ResponseBody = JsonConvert.DeserializeObject<ArtistAlbums>(resBody);
                return serviceResponse;
            }
            else
            {
                serviceResponse.ErrorMessage = "Unable to fetch artist albums";
                return serviceResponse;
            }
            
        }

           }
}
