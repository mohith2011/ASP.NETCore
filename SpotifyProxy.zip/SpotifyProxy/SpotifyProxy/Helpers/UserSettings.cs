﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Helpers
{
    public class UserSettings
    {
        public String ApiBase { get; set; }
        public String TokenBase { get; set; }
        public String TokenPath { get; set; }
        public String Apipath1 { get; set; }
        public String Apipath2 { get; set; }
        public String ClientId { get; set; }
        public String Secret { get; set; }
        public AuditLog AuditLog { get; set; }
    }

    public class AuditLog
    {    
        public bool Enable { get; set; }
        public string Path { get; set; }
        public string RollingInterval { get; set; }
        public bool Shared { get; set; }
        public int RetainedFileCountLimit { get; set; }  
    }
}
