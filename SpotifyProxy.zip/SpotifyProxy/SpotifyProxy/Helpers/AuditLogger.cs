﻿using SpotifyProxy.Middleware;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpotifyProxy.Helpers
{
    public class AuditLogger
    {
        /// <summary>
        /// AuditRequestLog
        /// </summary>
        /// <param name="transactionID"></param>
        /// <param name="method"></param>
        /// <param name="path"></param>
        /// <param name="queryString"></param>
        /// <param name="payload"></param>
        public static void RequestInfo(string transactionID, string method, string path, string queryString, string payload)
        {
            AuditMiddleware.Logger.Information(
                string.Format("Request:TransactionID-{0}, Method-{1}, Path-{2}, QueryString-{3}, Payload-{4}",
                transactionID, method, path, queryString, payload
                ));
        }

        /// <summary>
        /// Audit Response Log
        /// </summary>
        /// <param name="transactionID"></param>
        /// <param name="method"></param>
        /// <param name="path"></param>
        /// <param name="queryString"></param>
        /// <param name="payload"></param>
        public static void ResponseInfo(string transactionID, string method, string path, string queryString, string payload)
        {
            AuditMiddleware.Logger.Information(
                string.Format("Response:TransactionID-{0}, Method-{1}, Path-{2}, QueryString-{3}, Payload-{4}",
                transactionID, method, path, queryString, payload
                ));
        }
    }
}
