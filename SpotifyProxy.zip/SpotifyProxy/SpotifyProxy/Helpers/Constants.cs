﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SpotifyProxy.Helpers
{
    public class Constants
    {
        #region ErrorHandler
        public const string InternalServerError = "Unknown Error";
        public const string BadRequestError = "InvalidRequest";
        public const int BadRequestHttpCode = (int)HttpStatusCode.BadRequest;
        public const int InternalServerErrorHttpCode = (int)HttpStatusCode.InternalServerError;
        public const int SuccessHttpCode = (int)HttpStatusCode.OK;
        public const int NotFoundHttpCode = (int)HttpStatusCode.NotFound;
        public const int ForbiddenHttpCode = (int)HttpStatusCode.Forbidden;
        #endregion

        #region Controller
        public const string Health = "IsAlive Request";
        public const string JsonContentType = "application/json";
        public const string SampleApiRoute = "api/v{version:apiVersion}";
        public const string InvalidRequestError = "Invalid Request";
        #endregion

    }
}
