using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using AutoMapper;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SpotifyProxy.Helpers;
using SpotifyProxy.Services;
using Serilog;
using Polly;
using System.Net.Http;
using Polly.Extensions.Http;
using SpotifyProxy.Middleware;
using Polly.Timeout;
using StackExchange.Profiling;
using Polly.Wrap;
using System.Net;

namespace SpotifyProxy
{
    public class Startup
    {
        private static readonly List<HttpStatusCode> _retryFor = new List<HttpStatusCode>() {
            HttpStatusCode.RequestTimeout,
            HttpStatusCode.BadGateway,
            HttpStatusCode.ServiceUnavailable,
            HttpStatusCode.GatewayTimeout
        };
        private AsyncPolicyWrap<HttpResponseMessage> _spotifyPolicyWrap;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            var timeoutPolicy = Policy.TimeoutAsync(TimeSpan.FromMilliseconds(Convert.ToInt16(10000)),
                TimeoutStrategy.Pessimistic,
                onTimeoutAsync: (callContext, span, task) => {
                    MiniProfiler.Current.Step($"Spotify timeout fired");
                    Log.Warning($"[Spotify Timeout]: Timeout policy fired, timespan-{span}");
                    return System.Threading.Tasks.Task.CompletedTask;
                });

            var retryPolicy = Policy.Handle<HttpRequestException>()
                .OrResult<HttpResponseMessage>(r => _retryFor.Contains(r.StatusCode))
                .RetryAsync(
                Convert.ToInt16(1),
                onRetryAsync: async (exception, retryNumber, context) =>
                {
                    await System.Threading.Tasks.Task.Run(() => {
                        MiniProfiler.Current.Step($"Spotify retry fired");
                        Log.Warning($"[Spotify]: Retry policy fired, retryCount - {retryNumber} status - { exception.Result.StatusCode}");
                    });
                });
            _spotifyPolicyWrap = timeoutPolicy.WrapAsync(retryPolicy);

        }
      
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(Configuration).CreateLogger();

            services.AddControllers();
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.Configure<UserSettings>(options => { Configuration.GetSection("usersettings").Bind(options); });
            services.AddHttpClient("GetToken", client =>
            {
                client.BaseAddress = new Uri(Configuration["usersettings:tokenBase"]);

            }).AddPolicyHandler(_spotifyPolicyWrap);

            services.AddHttpClient("GetSpotifyClient", client =>
            {
                client.BaseAddress = new Uri(Configuration["usersettings:apiBase"]);

            }).AddPolicyHandler(_spotifyPolicyWrap);
            services.AddSingleton<ISpotifyProxyService, SpotifyProxyService>();
            services.AddSingleton<ITokenService, TokenService>();

            services.AddMiniProfiler(opts =>
            {
                opts.RouteBasePath = Configuration["usersettings:BasePath"] + "/miniprofiler";
            });

            services.AddSwaggerDocument();

            services.AddApiVersioning();

        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSerilogRequestLogging();
            app.UseOpenApi();
            app.UseSwaggerUi3();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();
            app.UseMiniProfiler();
            app.UseMiddleware(typeof(AuditMiddleware));
            app.UseMiddleware(typeof(ErrorHandlerMiddleware));
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
